import pandas as pd
import numpy as np
import torch
from torch.utils.data import random_split, Dataset
import torch.nn as nn
import torchmetrics

# 1. 读取csv文件，赋值为df
df = pd.read_csv(r'C:\Users\Administrator\Desktop\AI_Exam_Projects\人工智能训练师培训1206\张三+001+2\数字图片\digit.csv')
# 2. 提取图片特征X和标签Y
Y = df['label'].values
X = df.drop('label', axis=1).values
# 3. 数据格式转化为torch格式；转化 X和Y的数据类型
X = torch.tensor(X, dtype=torch.float32)
Y = torch.tensor(Y, dtype=torch.int64)
# 4. 改变每个样本的shape为28,28
X = X.view(-1, 28, 28)
# 5 标准化
mean = X.mean()
std = X.std()

X_normalized = (X - mean) / std
# 6. 构建torch框架的Dataset类，类名为my_dataset
class my_dataset(Dataset):
    def __init__(self, features, labels, mean=None, std=None):
        self.features = features
        self.labels = labels
    def __len__(self):
        return len(self.labels)
    def __getitem__(self, idx):
        return self.features[idx], self.labels[idx]
full_dataset = my_dataset(X_normalized, Y)
# 7. 基于torch工具包的random_split函数进行数据集的划分
train_size = int(0.7 * len(full_dataset))
test_size = len(full_dataset) - train_size
train, test = random_split(full_dataset, [train_size, test_size])
#读取数据并划分数据集
data_loader = torch.utils.data.DataLoader(dataset=train,batch_size=2000, shuffle=True)
data_loader2 = torch.utils.data.DataLoader(dataset=test,batch_size=2000, shuffle=True)
class MyNet(nn.Module):
    def __init__(self):
        super(MyNet, self).__init__()

        self.c1 = nn.Conv2d(1, 32, 7, 2, 3)
        self.b1 = nn.BatchNorm2d(32)

        self.c2 = nn.Conv2d(32, 64, 5, 2, 2)
        self.b2 = nn.BatchNorm2d(64)

        self.L1 = nn.Linear(3136, 10)
    def forward(self, x):
        out = self.c1(x)
        out = self.b1(out)
        out = torch.relu(out)

        out = self.c2(out)
        out = self.b2(out)
        out = torch.relu(out)

        out = torch.flatten(out, start_dim=1)
        out = self.L1(out)

        return out
model = MyNet()
#训练并保存模型
lossf = nn.CrossEntropyLoss()
optimizer =  torch.optim.Adam(model.parameters(), lr=0.01)
metricsf =  torchmetrics.Accuracy(task='multiclass', num_classes=10)

for i in range(5):
    for batchX, batchY in data_loader:
        # 添加通道维度以适应卷积层输入
        batchX = batchX.unsqueeze(1)
        # 清空梯度数据
        optimizer.zero_grad()
        # 前向传播，计算模型输出
        outputs = model(batchX)
        # 计算loss值
        loss = lossf(outputs, batchY)
        # 求解梯度
        loss.backward()
        # 更新模型参数
        optimizer.step()
        # 计算正确率指标
        metricsf(outputs, batchY)
        acc = metricsf.compute()
        # 打印loss值和正确率指标
        print(f'{loss.item():.4f}, {acc:.4f}')
        # 清空指标数据
        metricsf.reset()
# 训练完成后保存模型
torch.save(model.state_dict(), '2-2model_test.pth')
print("模型已保存为 '2-2model_test.pth'")