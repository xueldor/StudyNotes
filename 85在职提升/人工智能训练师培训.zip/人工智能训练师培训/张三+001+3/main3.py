import pandas as pd
import torch
import numpy as np

df = pd.read_csv(r'C:\Users\Administrator\Desktop\AI_Exam_Projects\人工智能训练师培训\张三+001+3\Employee.csv')
X = df.loc[:, df.columns != 'LeaveOrNot']
Y = df['LeaveOrNot']

X = pd.get_dummies(X, dtype=float)
X = X.to_numpy()
X = torch.from_numpy(X)

Y = Y.to_numpy()
Y = torch.from_numpy(Y)

u = X.mean(dim=0)
std = X.std(dim=0)
X = ( X - u ) / std

X = X.to(torch.float32)
Y = Y.to(torch.int64)

from torch.utils.data import DataLoader,random_split

class my_dataset(torch.utils.data.Dataset):
    def __init__(self, ):
        pass

    def __getitem__(self, index):
        return X[index], Y[index]

    def __len__(self):
        return len(X)

train, test = random_split(my_dataset(), (int(len(X) * 0.8), len(X) - int(len(X) * 0.8) ) )
data_loader = torch.utils.data.DataLoader(dataset=train,batch_size=2000, shuffle=True)
data_loader2 = torch.utils.data.DataLoader(dataset=test,batch_size=2000, shuffle=True)

import torch.nn as nn


# 补全神经网络设计代码

class MyNet(nn.Module):
    def __init__(self):
        super(MyNet, self).__init__()
        # 获取输入特征维度
        input_dim = X.shape[1]

        # 第一层神经网络
        self.L1 = nn.Linear(input_dim, 128)
        self.B1 = nn.BatchNorm1d(128)

        # 第二层神经网络
        self.L2 = nn.Linear(128, 256)
        self.B2 = nn.BatchNorm1d(256)

        # 第三层神经网络（输出层）
        self.L3 = nn.Linear(256, 2)

    def forward(self, x):
        # 第一层：线性计算 + BatchNorm + ReLU
        out = self.L1(x)
        out = self.B1(out)
        out = torch.relu(out)

        # 第二层：线性计算 + BatchNorm + ReLU
        out = self.L2(out)
        out = self.B2(out)
        out = torch.relu(out)

        # 第三层：线性计算（无需softmax，因为CrossEntropyLoss会自动处理）
        out = self.L3(out)
        return out

model = MyNet()

import torchmetrics

lossf = nn.CrossEntropyLoss()
optimizer =  torch.optim.Adam(model.parameters(), lr=0.01)
metricsf =  torchmetrics.Accuracy(task='multiclass', num_classes=2)

for i in range(100):
    for batchX, batchY in data_loader:
        score = model(batchX)
        score = torch.squeeze(score)
        loss = lossf(score, batchY)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        metricsf(score, batchY)

    print(loss, metricsf.compute())
    metricsf.reset()