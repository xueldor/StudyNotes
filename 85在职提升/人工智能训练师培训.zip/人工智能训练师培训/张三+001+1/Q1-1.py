import os
from PIL import Image
input_folder = r'C:\Users\Administrator\Desktop\AI_Exam_Projects\人工智能训练师培训\张三+001+1\dataset'
output_folder= r'C:\Users\Administrator\Desktop\AI_Exam_Projects\人工智能训练师培训\张三+001+1\result1'
for filename in os.listdir(input_folder):# 遍历输入文件夹中的所有文件
    #【填空1】判断图像文件名是否以.png结尾，在此处修改代码
    if filename.lower().endswith('.png'):
        image_path = os.path.join(input_folder, filename)
        with Image.open(image_path) as img:
            #【填空2】判断图像尺寸是否等于100*100，在此处修改代码
            if not (img.width == 100 and img.height == 100):
                continue
            output_path = os.path.join(output_folder, filename)
            img.save(output_path)  # 保存有效的图像
print('处理完毕')
