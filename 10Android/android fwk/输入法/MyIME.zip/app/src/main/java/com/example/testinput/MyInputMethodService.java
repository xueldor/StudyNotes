package com.example.testinput;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

public class MyInputMethodService extends InputMethodService {
    private static final String TAG = "MyInputMethodService";
    View mCustomKeyboardView;


    @Override
    public void onCreate() {
        super.onCreate();
        // 1. 加载键盘布局
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mCustomKeyboardView = inflater.inflate(R.layout.keyboard_layout, null);
        // 2. 初始化键盘配置
        KeyboardView keyboardView = mCustomKeyboardView.findViewById(R.id.keyboardView);
        Keyboard keyboard = new Keyboard(this, R.xml.keylayout);
        keyboardView.setKeyboard(keyboard);

        // 3. 设置按键监听器
        keyboardView.setOnKeyboardActionListener(new SimpleOnKeyboardActionListener());
    }

    @Override
    public View onCreateInputView() {
        Log.i(TAG, "xxx onCreateInputView");
        // 创建并返回输入法界面
        return mCustomKeyboardView;
    }
    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        Log.i(TAG, "xxx onStartInputView");
        // 处理输入框焦点事件
        super.onStartInputView(info, restarting);
    }

    class SimpleOnKeyboardActionListener implements KeyboardView.OnKeyboardActionListener {

        @Override
        public void onPress(int primaryCode) {

        }

        @Override
        public void onRelease(int primaryCode) {

        }

        @Override
        public void onKey(int primaryCode, int[] keyCodes) {
            // 处理按键事件（如发送字符到输入框）
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.commitText(String.valueOf((char) primaryCode), 1);
                }
        }

        @Override
        public void onText(CharSequence text) {

        }

        @Override
        public void swipeLeft() {

        }

        @Override
        public void swipeRight() {

        }

        @Override
        public void swipeDown() {

        }

        @Override
        public void swipeUp() {

        }
    }
}